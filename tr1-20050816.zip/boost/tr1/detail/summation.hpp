//  (C) Copyright John Maddock 2005.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_TR1_SUMMATION_HPP_INCLUDED
#  define BOOST_TR1_SUMMATION_HPP_INCLUDED

namespace boost{
namespace tr1_detail{

template <class Functor>
typename Functor::result_type do_sum(Functor& func, typename Functor::result_type result, typename Functor::result_type terminator)
{
   typedef typename Functor::result_type real_type;
   static const int digits3 = std::numeric_limits<real_type>::digits / 3;
   if(terminator < 0)
      terminator = result * std::numeric_limits<real_type>::epsilon();
   real_type next_term;
   do{
      next_term = func();
      if(next_term < terminator)
         return result;
      if(next_term < (result / digits3))
         return do_sum(func, next_term, terminator) + result;
      result += next_term;
   }while(true);
   // we never actually get here:
   return result;
}

template <class Functor>
typename Functor::result_type sum(Functor& func)
{
   return do_sum(func, func(), -1);
}

template <class T>
class log1p_terms
{
   // produce successive terms for log(1+x):
public:
   log1p_terms(T x) : m_x(x), m_result(x), m_sign(1), m_div(1){}
   typedef T result_type;
   T operator()()
   {
      T result = m_result;
      ++m_div;
      m_sign *= -1;
      m_result = m_result * m_x * T(m_sign) / T(m_div);
      return result;
   }
private:
   T m_x;
   T m_result;
   int m_sign;
   int m_div;
};

template <class T>
T log1p(T x)
{
   log1p_terms<T> func(x);
   return ::boost::tr1_detail::sum(func);
}

} }

#endif


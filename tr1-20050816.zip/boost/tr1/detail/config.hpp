//  (C) Copyright John Maddock 2005.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_TR1_DETAIL_CONFIG_HPP_INCLUDED
#  define BOOST_TR1_DETAIL_CONFIG_HPP_INCLUDED
#  include <boost/config.hpp>

#  if defined(__SGI_STL_PORT) || defined(_STLPORT_VERSION)
#     define BOOST_TR1_STD_HEADER(name) <../stlport/##name>
#  else
#     define BOOST_TR1_STD_HEADER(name) <../include/##name>
#  endif

#ifdef BOOST_HAS_TR1
   // turn on support for everything:
#  define BOOST_HAS_TR1_REFERENCE_WRAPPER
#  define BOOST_HAS_TR1_SHARED_PTR

#endif

#endif


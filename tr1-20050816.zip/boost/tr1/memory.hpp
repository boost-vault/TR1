//  (C) Copyright John Maddock 2005.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_TR1_MEMORY_HPP_INCLUDED
#  define BOOST_TR1_MEMORY_HPP_INCLUDED
#  include <boost/tr1/detail/config.hpp>
#  include <memory>

#ifndef BOOST_HAS_TR1_SHARED_PTR

#define BOOST_TR1_NO_FULL_FUNCTIONAL
// we have to disable inclusion of the TR1 version of
// functional here, otherwise we will get error from
// some std lib implementations:
#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#undef BOOST_TR1_NO_FULL_FUNCTIONAL

namespace std{ namespace tr1{

   using ::boost::bad_weak_ptr;
   using ::boost::shared_ptr;
   using ::boost::swap;
   using ::boost::static_pointer_cast;
   using ::boost::dynamic_pointer_cast;
   using ::boost::const_pointer_cast;
   using ::boost::get_deleter;
   using ::boost::weak_ptr;
   using ::boost::enable_shared_from_this;

} }

#endif

#endif

